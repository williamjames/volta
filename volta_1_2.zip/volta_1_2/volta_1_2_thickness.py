import sys, arcpy, traceback, math, string, os, fileinput, numpy, datetime
from scipy.spatial import cKDTree as KDTree
from arcpy.sa import *
from arcpy import env
import arcpy.cartography as CA
arcpy.env.overwriteOutput = True
arcpy.Delete_management("in_memory")
def points_on_line(line, resolution):
    new_points = arcpy.CreateFeatureclass_management("in_memory", "points","POINT")
    arcpy.AddField_management(new_points, "distance", "DOUBLE")
    arcpy.AddField_management(new_points, "flow_id", "LONG")
    new_points_cursor = arcpy.da.InsertCursor(new_points, ('SHAPE@',"distance","flow_id")) 
    with arcpy.da.SearchCursor(line, ["SHAPE@LENGTH", "SHAPE@", "line_id"]) as cursor:
        for row in cursor:
            start = 0
            length = row[0]
            while start < length:
                new_point = row[1].positionAlongLine(start)
                new_points_cursor.insertRow((new_point,start,row[2]))
                start = start + resolution          
    return new_points
def create_perpendiculars(in_lines, distance):
    perpendiculars = arcpy.CreateFeatureclass_management("in_memory", "perpendiculars","POLYLINE")
    new_line_cursor = arcpy.da.InsertCursor(perpendiculars, ('SHAPE@'))
    with arcpy.da.SearchCursor(in_lines, ["SHAPE@"]) as cursor:                                   
        for row in cursor:
            startx = row[0].firstPoint.X
            starty = row[0].firstPoint.Y
            endx = row[0].lastPoint.X
            endy = row[0].lastPoint.Y
            midx = row[0].centroid.X
            midy = row[0].centroid.Y
            if starty==endy or startx==endx:
                if starty == endy:
                    y1 = starty + distance
                    y2 = starty - distance
                    x1 = startx
                    x2 = startx
                if startx == endx:
                    y1 = starty
                    y2 = starty 
                    x1 = startx + distance
                    x2 = startx - distance     
            else:
                m = ((starty - endy)/(startx - endx)) #get the slope of the line
                negativereciprocal = -1*((startx - endx)/(starty - endy))    #get the negative reciprocal
                if m > 0:
                    if m >= 1:
                        y1 = negativereciprocal*(distance)+ starty
                        y2 = negativereciprocal*(-distance) + starty
                        x1 = startx + distance
                        x2 = startx - distance
                    if m < 1:
                        y1 = starty + distance
                        y2 = starty - distance
                        x1 = (distance/negativereciprocal) + startx
                        x2 = (-distance/negativereciprocal)+ startx           
                if m < 0:
                    if m >= -1:
                        y1 = starty + distance
                        y2 = starty - distance
                        x1 = (distance/negativereciprocal) + startx
                        x2 = (-distance/negativereciprocal)+ startx     
                    if m < -1:
                        y1 = negativereciprocal*(distance)+ starty
                        y2 = negativereciprocal*(-distance) + starty
                        x1 = startx + distance
                        x2 = startx - distance
            array = arcpy.Array([arcpy.Point(x1,y1),arcpy.Point(x2, y2)])
            polyline = arcpy.Polyline(array)
            new_line_cursor.insertRow([polyline])
        del cursor
        del row
    return perpendiculars
def check_line_direction(line_in): # FUNCTION TO CHECK DIRECTION OF LINE. IF LINE IS IN WRONG DIRECTION (startpoint higher than endpoint) IT IS FLIPPED
    line_startpoint = arcpy.FeatureVerticesToPoints_management(line_in, "in_memory\\line_in_startpoint", "START")
    line_endpoint = arcpy.FeatureVerticesToPoints_management(line_in, "in_memory\\line_in_endpoint", "END")
    startpoint_ele = ExtractValuesToPoints(line_startpoint, dem,"in_memory\\startpoint_point_ele") #Get elevation of each point
    endpoint_ele = ExtractValuesToPoints(line_endpoint, dem,"in_memory\\endpoint_point_ele") #Get elevation of each point
    startpoint_list = []
    endpoint_list = []
    with arcpy.da.SearchCursor(startpoint_ele, "RASTERVALU") as cursor:
        for row in cursor:
            startpoint_list.append(row[0])
    with arcpy.da.SearchCursor(endpoint_ele, "RASTERVALU") as cursor:
        for row in cursor:
            endpoint_list.append(row[0])
    if startpoint_list[0] > endpoint_list[0]:
        arcpy.FlipLine_edit(line_in)     
def shear_stress(flowline, outline): 
    cellsize = arcpy.GetRasterProperties_management(dem,"CELLSIZEX")
    cellsize_value = int(cellsize.getOutput(0))
    ele_diff_dict = {}
    flowline_layer = arcpy.MakeFeatureLayer_management(flowline, "in_memory\\flowline_layer_ss")   
    with arcpy.da.SearchCursor(flowline,["line_id","SHAPE@LENGTH",arcpy.Describe(flowline).OIDFieldName]) as cursor:
        for row in cursor:
            flowline_query_ss = "line_id = "+str(row[0])
            arcpy.SelectLayerByAttribute_management(flowline_layer,"NEW_SELECTION",flowline_query_ss)
            single_flowline_multipart = arcpy.CopyFeatures_management(flowline_layer, "in_memory\\single_flowline_multi")
            arcpy.SelectLayerByAttribute_management(flowline_layer,"CLEAR_SELECTION")
            single_flowline = arcpy.Dissolve_management(single_flowline_multipart, "in_memory\\single_flowline_ss")
            single_flowline_count_query = arcpy.GetCount_management(single_flowline)
            single_flowline_count = int(single_flowline_count_query.getOutput(0))
            line_startpoint = arcpy.FeatureVerticesToPoints_management(single_flowline, "in_memory\\line_in_startpoint", "START")
            startpoint_count_query = arcpy.GetCount_management(line_startpoint)
            startpoint_count = int(startpoint_count_query.getOutput(0))
            line_endpoint = arcpy.FeatureVerticesToPoints_management(single_flowline, "in_memory\\line_in_endpoint", "END")
            endpoint_count_query = arcpy.GetCount_management(line_endpoint)
            endpoint_count = int(endpoint_count_query.getOutput(0))
            startpoint_ele = ExtractValuesToPoints(line_startpoint, dem,"in_memory\\startpoint_point_ele") #Get elevation of each point
            endpoint_ele = ExtractValuesToPoints(line_endpoint, dem,"in_memory\\endpoint_point_ele") #Get elevation of each point
            with arcpy.da.SearchCursor(startpoint_ele, "RASTERVALU") as cursor:
                for row_sp in cursor:
                    startpoint_ele_value = row_sp[0]
            with arcpy.da.SearchCursor(endpoint_ele, "RASTERVALU") as cursor:
                for row_ep in cursor:
                    endpoint_ele_value = row_ep[0]
            if startpoint_ele_value > endpoint_ele_value:
                arcpy.FlipLine_edit(single_flowline)
                startpoint_ele_value_original = startpoint_ele_value
                endpoint_ele_value_original = endpoint_ele_value
                startpoint_ele_value = endpoint_ele_value_original
                endpoint_ele_value = startpoint_ele_value_original
            ele_diff = endpoint_ele_value - startpoint_ele_value
            index = ele_diff
            value = [row[0],startpoint_ele_value,endpoint_ele_value,row[1]]
            ele_diff_dict[index] = value
    max_ele_diff = max(ele_diff_dict)
    max_dict_entry = ele_diff_dict[max_ele_diff]
    max_objectid = max_dict_entry[0]
    startpoint_ele_value_primary = max_dict_entry[1]
    endpoint_ele_value_primary = max_dict_entry[2]
    length_primary = max_dict_entry[3]
    sorted_dict = sorted(ele_diff_dict, reverse=True)
    dict_length = len(ele_diff_dict)
    fl_order = 0
    while fl_order < dict_length:
        ele_diff_sort = sorted_dict[fl_order]
        id = ele_diff_dict[ele_diff_sort][0]
        index_order = id
        value_order = fl_order
        order_dict[index_order] = value_order
        fl_order = fl_order + 1
    flowline_layer = arcpy.MakeFeatureLayer_management(flowline, "in_memory\\flowline_layer")
    flowline_query = "line_id = "+str(max_objectid)
    arcpy.SelectLayerByAttribute_management(flowline_layer,"NEW_SELECTION",flowline_query)
    primary_flowline = arcpy.CopyFeatures_management(flowline_layer, "in_memory\\single_flowline")
    arcpy.AddField_management(primary_flowline, "zero", "FLOAT")
    arcpy.AddField_management(primary_flowline, "max_dist", "FLOAT")
    arcpy.CalculateField_management(primary_flowline,"zero",0)
    arcpy.CalculateField_management(primary_flowline,"max_dist",length_primary)
    dem_glac_clip = arcpy.Clip_management(dem, "#", "in_memory\\dem_glac_clip",outline,"","ClippingGeometry")
    dem_glac_clip_square = arcpy.Clip_management(dem, "#", "in_memory\\dem_glac_clip_square",outline)
    raster = arcpy.Raster(dem_glac_clip)
    array = arcpy.RasterToNumPyArray(raster,"","","",0)
    count = numpy.count_nonzero(array)
    contour_list = []
    if max_ele_diff >= 200.0:
        contour_interval = 200.0
        contour_value = startpoint_ele_value_primary + contour_interval
        while contour_value < endpoint_ele_value_primary:
            contour_list.append(contour_value)
            contour_value = contour_value + contour_interval   
        route = arcpy.CreateRoutes_lr(primary_flowline, "zero", "in_memory\\route_layer", "TWO_FIELDS", "zero","max_dist")
        shear_list = []
        for value in contour_list:
            area = ((((value - contour_interval) < array) & (array < value)).sum())*cellsize_value*cellsize_value
            contour_shear_stress = ContourList(dem_glac_clip_square, "in_memory\\contour_shear_stress", value)
            contour_shear_stress_dissolve = arcpy.Dissolve_management(contour_shear_stress, "in_memory\\dissolve_contour_ss")
            intersect_point_ss = arcpy.Intersect_analysis ([contour_shear_stress_dissolve, primary_flowline], "in_memory\\ss_intersect", "","","POINT")
            route_table = arcpy.LocateFeaturesAlongRoutes_lr(intersect_point_ss, route , "zero", 2, "in_memory\\route_table")
            with arcpy.da.SearchCursor(route_table, ["MEAS"]) as cursor:
                for row in cursor:
                    segment_length = row[0] 
            angle_rad = math.atan(contour_interval/segment_length)
            area_cos = area/(math.cos(angle_rad))
            shear_list.append(area_cos)
        sum_a_cos = sum(shear_list)
        shear_stress_out = 27000* sum_a_cos**0.106
        if shear_stress_out < 10000 or shear_stress_out > 300000:
            shear_stress_out = 100000
            arcpy.AddMessage("WARNING: error in auto-calculation of shear stress, using 100,000 Kpa")
    else:
        arcpy.AddMessage("WARNING: glacier altitudinal extent < 200m. using 100,000 Kpa")
        shear_stress_out = 100000
    return shear_stress_out
flowline = arcpy.GetParameterAsText(0)
dem = arcpy.GetParameterAsText(1)
outline = arcpy.GetParameterAsText(2)
ice_density = int(arcpy.GetParameterAsText(3))
slope_limit = arcpy.GetParameterAsText(4)
min_slope = float(arcpy.GetParameterAsText(5))
point_res_check = arcpy.GetParameterAsText(6)
cellsize = arcpy.GetRasterProperties_management(dem,"CELLSIZEX")
cellsize_int = int(cellsize.getOutput(0))
if point_res_check == "true":
    point_res = cellsize_int   
else:
    point_res = int(arcpy.GetParameterAsText(7))
shear_stress_test = arcpy.GetParameterAsText(8)
shear_stress_value = arcpy.GetParameterAsText(9)
final_points = arcpy.GetParameterAsText(10)
interpolate_check = arcpy.GetParameterAsText(11)
cellsize_interpolate_check = arcpy.GetParameterAsText(12)
cellsize_interpolate_user_spec = arcpy.GetParameterAsText(13)
raster_out = arcpy.GetParameterAsText(14)
arcpy.env.outputCoordinateSystem = outline
counter = 1
output_list = []
gravity = 9.81
effective_slope_limit = slope_limit
arcpy.AddMessage("Ice density set at: "+str(ice_density)+" kg/m/3")          
arcpy.AddMessage("Effective slope limit set at: "+str(effective_slope_limit)+" degrees")
arcpy.AddMessage("Minimum slope threshold set at: "+str(min_slope)+" degrees")
exist_fields_list_centrelines = [f.name for f in arcpy.ListFields(flowline)] #List of current field names in outline layer
line_fields = ["line_id"]
for field in line_fields:
    if field not in exist_fields_list_centrelines:
        arcpy.AddField_management(flowline, field, "LONG")
arcpy.CalculateField_management(flowline,"line_id",str("!"+str(arcpy.Describe(flowline).OIDFieldName)+"!"),"PYTHON_9.3")
exist_fields_list_outlines = [f.name for f in arcpy.ListFields(outline)] #List of current field names in outline layer
outline_fields = ["stress_pa", "outline_id"]
for field in outline_fields:
    if field not in exist_fields_list_outlines:
        arcpy.AddField_management(outline, field, "LONG")
if "va_thick" not in exist_fields_list_outlines:
     arcpy.AddField_management(outline, "va_thick", "DOUBLE")
arcpy.CalculateField_management(outline,"outline_id",str("!"+str(arcpy.Describe(outline).OIDFieldName)+"!"),"PYTHON_9.3")
flow_id_list = []
with arcpy.da.SearchCursor(flowline, ["line_id"]) as cursor:
    for row in cursor:
        flow_id_list.append(row[0])
with arcpy.da.UpdateCursor(outline, ["Shape_Area","va_thick"]) as cursor:
    for row in cursor:
        area_km2 = row[0]/1000.0/1000.0
        if area_km2 <= 25.0:
            row[1]= (0.0435*area_km2**1.23)/area_km2*1000
        else:
            row[1]= (0.0540*area_km2**1.20)/area_km2*1000
        cursor.updateRow(row)
outline_layer = arcpy.MakeFeatureLayer_management(outline, "in_memory\\outline_layer")
flowline_layer_join = arcpy.MakeFeatureLayer_management(flowline, "in_memory\\flowline_layer_join")
order_dict = {}
max_length_dict = {}
with arcpy.da.UpdateCursor(outline_layer, ["outline_id","stress_pa"]) as cursor:
    for row in cursor:
        outline_query = "outline_id = "+str(row[0])
        arcpy.SelectLayerByAttribute_management(outline_layer,"NEW_SELECTION",outline_query)
        single_outline = arcpy.CopyFeatures_management(outline_layer, "in_memory\\single_outline")
        single_outline_layer = arcpy.MakeFeatureLayer_management(single_outline, "in_memory\\single_outline")
        arcpy.SelectLayerByLocation_management(flowline,"WITHIN_CLEMENTINI",single_outline_layer)
        subset_flowline = arcpy.CopyFeatures_management(flowline, "in_memory\\subset_flowlines")
        length_list = []
        with arcpy.da.SearchCursor(subset_flowline, ["SHAPE@LENGTH"]) as cursor_length:
            for row_length in cursor_length:
                length_list.append(row_length[0])
        max_length_outline = max(length_list)
        max_length_dict[row[0]] = max_length_outline
        if shear_stress_test == "true":
            shear_stress_value = shear_stress(subset_flowline, single_outline_layer)
            row[1] = int(shear_stress_value)
            cursor.updateRow(row)
            arcpy.AddMessage("Shear stress auto calculated for glacier outline "+str(row[0])+": "+str(row[1])+" Pa")
        else:
            shear_stress(subset_flowline, single_outline_layer)
            shear_stress_value = arcpy.GetParameterAsText(9)   
            row[1] = shear_stress_value
            cursor.updateRow(row)
            arcpy.AddMessage("User Defined Shear stress for glacier outline "+str(row[0])+": "+str(row[1])+" Pa")
        arcpy.SelectLayerByAttribute_management(outline_layer,"CLEAR_SELECTION")
        arcpy.SelectLayerByAttribute_management(flowline,"CLEAR_SELECTION")
flowline_joined = arcpy.SpatialJoin_analysis(flowline_layer_join, outline_layer,"in_memory\\flowline_joined","","","", "WITHIN_CLEMENTINI")
flowline_layer = arcpy.MakeFeatureLayer_management(flowline_joined, "in_memory\\flowline_layer2")
flowline_layer_split_vertex = arcpy.SplitLine_management(flowline_layer, "in_memory\\flowline_layer_split_vertex")
flowline_layer_split_vertex_layer = arcpy.MakeFeatureLayer_management(flowline_layer_split_vertex, "in_memory\\flowline_layer_split_vertex_layer")
with arcpy.da.SearchCursor(flowline_joined, ["line_id","outline_id", "stress_pa","SHAPE@LENGTH"]) as cursor:
    for row in cursor:
        if row[0] > 0:
            fl_length = row[3]
            arcpy.AddMessage("Calculating ice thickness on centreline "+str(counter) + ' of ' +str(len(flow_id_list)))
            shape_factor_list = []
            yield_stress = row[2]
            points_glac = "in_memory\\points_glac"+str(row[0])
            flowline_id = row[0]
            outline_id = row[1]
            flowline_query = "line_id = "+str(flowline_id)
            outline_layer = arcpy.MakeFeatureLayer_management(outline, "in_memory\\outline_layer2")
            outline_query = "outline_id = "+str(outline_id)
            arcpy.SelectLayerByAttribute_management(flowline_layer,"NEW_SELECTION",flowline_query)
            arcpy.SelectLayerByAttribute_management(outline_layer,"NEW_SELECTION",outline_query)
            single_flowline = arcpy.CopyFeatures_management(flowline_layer, "in_memory\\single_flowline")
            check_line_direction(single_flowline)
            single_outline = arcpy.CopyFeatures_management(outline_layer, "in_memory\\single_outline")
            with arcpy.da.SearchCursor(single_outline, "va_thick") as cursor:
                for row in cursor:
                    mean_ice_depth = row[0]
            search_dist_va = mean_ice_depth*15
            if search_dist_va > 2500:
                search_dist_va = 2500
            search_dist_va_round = int(round(search_dist_va/point_res)*point_res)
            if search_dist_va_round > fl_length*0.075:
                search_dist_va_round = int(round((fl_length*0.075)/point_res)*point_res)
            points_on_flowline = points_on_line(single_flowline, point_res)
            points_on_flowline_altitude = ExtractValuesToPoints(points_on_flowline, dem, "in_memory\\points_altitude")                
            split_flowline = arcpy.SplitLineAtPoint_management(single_flowline, points_on_flowline_altitude, "in_memory\\split_flowline", "1 meters")
            perpendiculars = create_perpendiculars(split_flowline, 1000000)
            clipped_perpendiculars = arcpy.Clip_analysis(perpendiculars, single_outline, "in_memory\\clipped_perpendiculars")
            simplified_perpendiculars = arcpy.SimplifyLine_cartography(clipped_perpendiculars,"in_memory\\simplified_perpendiculars","POINT_REMOVE", 1,"","NO_KEEP","NO_CHECK")
            split_simplified_perpendiculars = arcpy.SplitLine_management(simplified_perpendiculars,"in_memory\\split_simplified_perpendiculars")
            split_simplified_perpendiculars_layer = arcpy.MakeFeatureLayer_management(split_simplified_perpendiculars, "in_memory\\split_simplified_perpendiculars_layer")
            arcpy.SelectLayerByLocation_management(split_simplified_perpendiculars_layer,"INTERSECT",split_flowline)
            arcpy.SelectLayerByAttribute_management(split_simplified_perpendiculars_layer,"SWITCH_SELECTION")
            arcpy.DeleteFeatures_management(split_simplified_perpendiculars_layer)
            final_perpendiculars = arcpy.CopyFeatures_management(split_simplified_perpendiculars_layer, "in_memory\\final_perpendiculars")
            arcpy.AddField_management(final_perpendiculars,"orig_perp_ID", "LONG")
            arcpy.AddField_management(final_perpendiculars, "EW", "DOUBLE")
            arcpy.AddField_management(final_perpendiculars, "FW", "DOUBLE")
            arcpy.AddField_management(final_perpendiculars,"inter", "SHORT")
            arcpy.CalculateField_management(final_perpendiculars,"orig_perp_ID",str("!"+str(arcpy.Describe(final_perpendiculars).OIDFieldName)+"!"),"PYTHON_9.3")
            arcpy.CalculateField_management(final_perpendiculars,"FW","!SHAPE.LENGTH!","PYTHON_9.3")
            slope_reclass_string = "0"+" "+str(effective_slope_limit)+" "+"1"+";"+str(effective_slope_limit)+" "+"90"+" "+"NODATA"
            dem_glac_clip = arcpy.Clip_management(dem, "#", "in_memory\\dem_glac_clip",single_outline,"","ClippingGeometry")
            slope_raster = arcpy.Slope_3d(dem_glac_clip,"in_memory\\slope_raster", "DEGREE")
            reclass_slope_raster = arcpy.Reclassify_3d(slope_raster,"Value",slope_reclass_string,"in_memory\\reclass_slope_raster","NODATA")
            reclass_slope_polygons = arcpy.RasterToPolygon_conversion(reclass_slope_raster,"in_memory\\reclass_slope_polygons")
            final_perpendiculars_EW = arcpy.Clip_analysis(final_perpendiculars,reclass_slope_polygons, "in_memory\\final_perpendiculars_EW")
            arcpy.CalculateField_management(final_perpendiculars_EW,"EW","!SHAPE.LENGTH!","PYTHON_9.3")
            final_perpendiculars_EW_layer = arcpy.MakeFeatureLayer_management(final_perpendiculars_EW, "in_memory\\final_perpendiculars_EW_layer")
            final_perpendiculars_layer = arcpy.MakeFeatureLayer_management(final_perpendiculars, "in_memory\\final_perpendiculars_layer")
            arcpy.AddJoin_management(final_perpendiculars_layer, "orig_perp_ID", final_perpendiculars_EW_layer, "orig_perp_ID")
            arcpy.CalculateField_management(final_perpendiculars_layer,str("final_perpendiculars")+".EW","["+str("final_perpendiculars_EW")+".EW]")
            arcpy.RemoveJoin_management(final_perpendiculars_layer)
            arcpy.SelectLayerByLocation_management(flowline_layer_split_vertex_layer, "SHARE_A_LINE_SEGMENT_WITH", single_flowline)
            arcpy.SelectLayerByAttribute_management(flowline_layer_split_vertex_layer,"SWITCH_SELECTION")
            cross_test = arcpy.CopyFeatures_management(flowline_layer_split_vertex_layer, "in_memory\\cross_test")
            arcpy.SelectLayerByLocation_management(final_perpendiculars_layer, 'intersect', cross_test)
            arcpy.CalculateField_management(final_perpendiculars_layer,"inter",1)
            arcpy.SelectLayerByAttribute_management(final_perpendiculars_layer,"CLEAR_SELECTION")
            arcpy.SelectLayerByAttribute_management(flowline_layer_split_vertex_layer,"CLEAR_SELECTION")
            arcpy.SpatialJoin_analysis(points_on_flowline_altitude,final_perpendiculars_layer,points_glac,"","","","CLOSEST")
            final_points_count = arcpy.GetCount_management(points_glac)
            final_points_count_result = int(final_points_count.getOutput(0))
            arcpy.AddField_management(points_glac, "f_type", "TEXT","","",1)
            fields = ["FW","EW","distance","RASTERVALU","max_dist", "ew_thi", "degrees", "sm_thi","Thickness","f_type","inter","p_g_alpha","poly_id","shape_f","bed_ele","shape_ori","order_fl","flow_id","seq"]
            exist_fields_list = [f.name for f in arcpy.ListFields(points_glac)] #List of current field names
            for field in fields:
                if field not in exist_fields_list:  #Add required fields if they do not already exist
                    arcpy.AddField_management(points_glac, field, "DOUBLE")
            max_dist_list  = []
            with arcpy.da.SearchCursor(points_glac, ["flow_id","distance"]) as cursor:
                for row in cursor:  
                    if row[0] == flowline_id:
                        max_dist_list.append(row[1])
            max_dist = max(max_dist_list)
            with arcpy.da.UpdateCursor(points_glac, ["flow_id","max_dist"]) as cursor:
                for row in cursor:
                    if row[0] == flowline_id:
                        row[1] = max_dist
                        cursor.updateRow(row)  
            error_dict = {}    
            search_dist = search_dist_va_round              
            dict = {}
            with arcpy.da.SearchCursor(points_glac,fields) as cursor:
                for row in cursor:
                    index = row[2]
                    value = row[3]
                    dict[index] = value       
            with arcpy.da.UpdateCursor(points_glac,fields) as cursor:
                for row in cursor:
                    row[16] = order_dict[row[17]]
                    row[12] = outline_id
                    cursor.updateRow(row)
                    start_distance = row[2] - (search_dist)
                    end_distance = row[2] + (search_dist)
                    if start_distance >= 0 and end_distance <= row[4]:
                        diff_distance = end_distance - start_distance
                        start = start_distance              
                        start_ele = dict[start]
                        end = end_distance                                
                        end_ele = dict[end]
                        diff_ele = end_ele - start_ele                    
                        m = diff_ele/diff_distance                     
                        radians = math.atan(m)                
                        degrees = abs(radians*(180.0/math.pi))
                        row[6] = degrees
                        cursor.updateRow(row)
                        if degrees <= min_slope:
                            degrees = min_slope
                        cursor.updateRow(row)
                        rad_limit = degrees*(math.pi/180.0)
                        ice_depth_sm = yield_stress/(ice_density*gravity*((math.tan(rad_limit))))
                        row[7] = ice_depth_sm
                        row[11] = ice_density*gravity*((math.tan(rad_limit)))
                        if row[1] > 0:                              
                            row[5] = (0.9*(row[1]/2.0)*ice_depth_sm)/(0.9*(row[1]/2.0)-ice_depth_sm)
                            cursor.updateRow(row)
                        row[8] = row[5]
                        row[9] = "W"
                        cursor.updateRow(row)
                        if row[5] <= 0 or row[1] == None or row[10] ==1 or row[0] > 0.66*(max_length_dict[row[12]]):
                            row[9] = "A"
                            cursor.updateRow(row)
                        if row[10] == 1:
                            row[15] = 1
                            cursor.updateRow(row)       
                        if row[1] == None:
                            row[15] = 2
                            cursor.updateRow(row)
                        if row[5] <= 0:
                            row[15] = 3
                            cursor.updateRow(row)
                        if row[0] > 0.66*(max_length_dict[row[12]]):
                            row[15] = 4
                            cursor.updateRow(row)          
                        if row[9] == "W":
                            shape_factor = yield_stress/(row[5]*ice_density*gravity*((math.tan(rad_limit))))
                            row[13] = shape_factor
                            row[15] = shape_factor
                            if shape_factor <= 0.445:
                                row[9] = "A"
                                cursor.updateRow(row)
                        if row[9] == "W":
                            shape_factor_list.append(shape_factor)
                            cursor.updateRow(row)
                        if row[9] == "A":
                            shape_factor_list.append(0.8)
                            cursor.updateRow(row)             
                    else:
                        cursor.deleteRow()
            if len(shape_factor_list) == 0:
                mean_shape_factor = 0.8
            else:
                mean_shape_factor = numpy.mean(shape_factor_list)
            if mean_shape_factor < 0 or mean_shape_factor > 0.95:
                mean_shape_factor = 0.8      
            with arcpy.da.UpdateCursor(points_glac,fields) as cursor:
                for row in cursor:
                    if row[9] == "A":
                        row[8] = (yield_stress/(mean_shape_factor*row[11]))
                        row[13] = mean_shape_factor
                        cursor.updateRow(row)
                    row[14] = row[3] - row[8]
                    cursor.updateRow(row)
            del_fields = ["Join_Count","TARGET_FID","distance","flow_id","orig_perp_ID","inter","max_dist","ew_thi","sm_thi","p_g_alpha","shape_ori"]
            exist_fields_list = [f.name for f in arcpy.ListFields(points_glac)] #List of current field names
            for field in del_fields:
                if field in exist_fields_list:  #delete required fields 
                    arcpy.DeleteField_management(points_glac, field)
            if counter == 1:
                initial_fl_points = arcpy.CopyFeatures_management(points_glac, "in_memory\\initial_fl_points")
            else:
                merged_points = arcpy.Append_management(points_glac, initial_fl_points)
            counter = counter + 1
identical_table = arcpy.FindIdentical_management(merged_points, "in_memory\\identical_table", ["Shape"], output_record_option="ONLY_DUPLICATES")
exist_fields_list1 = [f.name for f in arcpy.ListFields(merged_points)]
points_layer = arcpy.MakeFeatureLayer_management(merged_points, "in_memory\\p_layer")
exist_fields_list2 = [f.name for f in arcpy.ListFields(points_layer)]
arcpy.AddJoin_management(points_layer,arcpy.Describe(points_layer).OIDFieldName,identical_table, "IN_FID")
exist_fields_list3 = [f.name for f in arcpy.ListFields(points_layer)]
arcpy.CalculateField_management(points_layer,"initial_fl_points.seq","!identical_table.FEAT_SEQ!","PYTHON_9.3")
arcpy.RemoveJoin_management (points_layer)
seq_list = []
with arcpy.da.SearchCursor(points_layer, ["seq","order_fl"]) as cursor:
    for row in cursor:
        if row[0] >= 1:
            seq_list.append(row[0])
for value in seq_list:
    order_list = []
    with arcpy.da.SearchCursor(points_layer, ["seq","order_fl"]) as cursor:
        for row in cursor:
            if row[0] == value:
                order_list.append(row[1])
    with arcpy.da.UpdateCursor(points_layer, ["seq","order_fl"]) as cursor:
        for row in cursor:
            if row[0] == value:
                if row[1] != min(order_list):
                    cursor.deleteRow()
arcpy.DeleteField_management(merged_points, "seq")
arcpy.CopyFeatures_management(merged_points, final_points)
arcpy.AddMessage("Centreline point thickness calculation complete")

if interpolate_check == "true":
    arcpy.AddMessage("Interpolating thickness raster")
    dissolve_outlines = arcpy.Dissolve_management(outline, "in_memory\\dissolve_outlines")
    singlepart_outlines = arcpy.MultipartToSinglepart_management(dissolve_outlines, "in_memory\\singlepart_outlines")
    singlepart_outlines_layer = arcpy.MakeFeatureLayer_management(singlepart_outlines, "in_memory\\singlepart_outlines_layer")
    exist_fields_list = [f.name for f in arcpy.ListFields(singlepart_outlines_layer)] #List of current field names in outline layer 
    outline_lines_in = arcpy.PolygonToLine_management(singlepart_outlines, "in_memory\\outlines_line_in")
    outline_lines_in_layer = arcpy.MakeFeatureLayer_management(outline_lines_in, "in_memory\\outline_lines_in_layer")
    arcpy.AddField_management(outline_lines_in_layer, "contour", "SHORT")
    arcpy.CalculateField_management(outline_lines_in_layer,"contour",0)
    if cellsize_interpolate_check == "true":
        cellsize_interp = cellsize_int
    else:
        cellsize_interp = cellsize_interpolate_user_spec            
    interpolated_ice_depth_original = TopoToRaster([TopoPointElevation([[merged_points, 'Thickness']]),  TopoContour([[outline_lines_in_layer, 'contour']]), TopoBoundary ([singlepart_outlines_layer])], cellsize_interp , "","",0, "", "NO_ENFORCE", "SPOT", "","",1,10,7,200,"","","","",0.1)
    interpolated_ice_depth_original.save(raster_out)
arcpy.Delete_management("in_memory")
                        

